// This file is duplicated and can be safely deleted.
// The AppLayout component is now exported from components/Shared.tsx
export default function AppLayout() { return null; }